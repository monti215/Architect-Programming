package com.example.inventoryproject2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseHelper {

    public static String COLUMN_NAME;
    public static String COLUMN_QUANTITY;
    public static String TABLE_ITEMS;
    public static String COLUMN_ID;

    public DatabaseHelper(Context context) {
    }

    public SQLiteDatabase getWritableDatabase() {
        return null;
    }

    public void close() {
    }
}

package com.example.inventoryproject2;

import java.util.ArrayList;

public class GridItem {
    private final String title;
    private final String value;

    public GridItem(String title, String value) {
        this.title = title;
        this.value = value;
    }

    public String getTitle() {
        return title;
    }

    public String getValue() {
        return value;
    }

    // Other getters and setters as needed
    ArrayList<GridItem> itemList = new ArrayList<>();
    GridItemAdapter adapter = new GridItemAdapter(itemList);
}

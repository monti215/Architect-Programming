package com.example.inventoryproject2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseManager {
    private SQLiteDatabase database;
    private final DatabaseHelper dbHelper;

    public DatabaseManager(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertItem(String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NAME, name);
        values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);

        database.insert(DatabaseHelper.TABLE_ITEMS, null, values);
        return 0;
    }

    public int updateItem(long id, int newQuantity) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_QUANTITY, newQuantity);

        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        return database.update(DatabaseHelper.TABLE_ITEMS, values, selection, selectionArgs);
    }

    public int deleteItem(long id) {
        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        return database.delete(DatabaseHelper.TABLE_ITEMS, selection, selectionArgs);
    }

    public Cursor getAllItems() {
        String[] projection = {
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_NAME,
                DatabaseHelper.COLUMN_QUANTITY
        };

        return database.query(
                DatabaseHelper.TABLE_ITEMS,
                projection,
                null,
                null,
                null,
                null,
                null
        );
    }
}
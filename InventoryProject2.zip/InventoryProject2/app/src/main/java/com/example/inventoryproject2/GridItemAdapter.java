package com.example.inventoryproject2;

import java.util.ArrayList;

public class GridItemAdapter {
    public GridItemAdapter(ArrayList<GridItem> itemList) {
    }
}

package com.example.inventoryproject2;

public class CreateAccountActivity {
}

package com.example.inventoryproject2;

import static com.example.inventoryproject2.R.layout.activity_grid_display;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    Button buttonLogin, buttonCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(this::onClick);

        buttonCreateAccount.setOnClickListener(v -> {
            // Implement logic to create a new account
            // For simplicity, let's assume it opens a new activity for account creation
            startActivity(new Intent(MainActivity.this, CreateAccountActivity.class));
        });

    }

    @SuppressLint({"CutPasteId", "WrongViewCast"})
    private void onClick(View v) {
        // Retrieve username and password from EditText fields
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        // Perform login authentication (replace with your own logic)
        if (username.equals("admin") && password.equals("password")) {
            // Successful login
            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
            // Add code to navigate to next screen
            setContentView(activity_grid_display);

        } else {
            // Invalid login
            Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
        }
        // Initialize the database manager
        DatabaseManager databaseManager = new DatabaseManager(this);
        databaseManager.open();

        Button buttonAddData, buttonDelete, buttonUpdate;
        buttonAddData = findViewById(R.id.buttonAddData);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open a dialog or start a new activity for adding an item
                // Retrieve the name and quantity from the input
                String name = null; // Retrieve the name from the input
                int quantity = 0; // Retrieve the quantity from the input

                // Insert the item into the database
                long itemId = databaseManager.insertItem(name, quantity);

            }
        });
    }
    }




























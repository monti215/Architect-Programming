package com.example.inventoryproject2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionPromptActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    Button buttonRequestPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_prompt);

        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);

        buttonRequestPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle permission request button click
                requestSmsPermission();
            }
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted
            Toast.makeText(this, "SMS Permission already granted", Toast.LENGTH_SHORT).show();
            // Proceed with SMS functionality
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // SMS permission granted
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
                // Implement logic for sending SMS notifications (e.g., low inventory, upcoming event, goal weight)
                // For demonstration, you can call a method to send a sample SMS notification
                sendSampleNotification();
            } else {
                // SMS permission denied
                Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
                // Implement fallback behavior
            }
        }
    }

    private void sendSampleNotification() {
    }


}

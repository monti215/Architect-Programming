package com.example.inventoryproject2;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.ViewHolder> {

    private final List<GridItem> itemList;

    public GridAdapter(List<GridItem> itemList) {
        this.itemList = itemList;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle, textViewValue;
        Button buttonDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewValue = itemView.findViewById(R.id.textViewValue);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        GridItem item = itemList.get(position);
        holder.textViewTitle.setText(item.getTitle());
        holder.textViewValue.setText(item.getValue());
        holder.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement delete functionality here
                // Remove item from list and notify adapter
                itemList.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return 0;
    }


}
